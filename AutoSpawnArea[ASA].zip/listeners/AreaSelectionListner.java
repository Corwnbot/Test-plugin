package com.yourname.autospawnerarea.listeners;

import com.yourname.autospawnerarea.AutospawnerAreaPlugin;
import org.bukkit.event.Listener;

public class AreaSelectionListener implements Listener {
    private final AutospawnerAreaPlugin plugin;

    public AreaSelectionListener(AutospawnerAreaPlugin plugin) {
        this.plugin = plugin;
    }

    // Implement the event handling for selecting areas with an axe
}